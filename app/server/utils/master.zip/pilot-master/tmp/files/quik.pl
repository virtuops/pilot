#!/usr/bin/perl

use JSON;

$string = '{index:{_index:object_server_events,_type:events}}';


print $string."\n";
